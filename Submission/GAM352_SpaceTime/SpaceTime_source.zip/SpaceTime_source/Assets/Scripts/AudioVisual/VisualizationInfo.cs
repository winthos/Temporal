﻿using UnityEngine;
using System.Collections;

public class VisualizationInfo : MonoBehaviour
{
    public Vector3 scale;

    void Awake()
    {
        scale = gameObject.transform.localScale;
    }

	// Use this for initialization
	void Start ()
    {
        VisualizerHub.AddObjectToCubes(this.gameObject, transform.localScale);
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
